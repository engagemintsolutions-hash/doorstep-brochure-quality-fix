import requests
import os

# Test the actual frontend workflow - upload photos and see what comes back
test_photo = r'C:\Users\billm\Documents\prop test run\36239_GUS250140_IMG_01_0000.jpeg'

print("Testing frontend API workflow...")
print("="*70)

# Upload 1 photo to /analyze-images endpoint
files = [
    ('files', open(test_photo, 'rb')),
]

print(f"\nUploading: {os.path.basename(test_photo)}")
print("Calling: POST http://localhost:8000/analyze-images\n")

response = requests.post('http://localhost:8000/analyze-images', files=files)

print(f"Response Status: {response.status_code}")
print(f"Response Headers: {dict(response.headers)}")
print(f"\nResponse Body:")
print("="*70)

if response.status_code == 200:
    import json
    result = response.json()
    print(json.dumps(result, indent=2))

    print("\n" + "="*70)
    print("DETECTED FEATURES:")
    print("="*70)
    for img in result:
        print(f"\nFilename: {img.get('filename')}")
        print(f"Room Type: {img.get('room_type')}")
        print(f"Attributes ({len(img.get('attributes', []))}):")
        for attr in img.get('attributes', []):
            print(f"  - {attr.get('attribute')} (confidence: {attr.get('confidence')})")
else:
    print(response.text)
    print("\nERROR!")
