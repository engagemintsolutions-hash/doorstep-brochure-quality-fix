import requests
import time

# Test the vision API endpoint
files = [
    ('files', open(r'C:\Users\billm\Documents\prop test run\36239_GUS250140_IMG_20_0000.jpeg', 'rb')),
]

print("Testing vision API at http://localhost:8000/analyze-images...")
print("Waiting for server to be ready...")
time.sleep(2)

response = requests.post('http://localhost:8000/analyze-images', files=files)

print(f"Status: {response.status_code}")
if response.status_code == 200:
    results = response.json()
    print(f"\nSUCCESS! Analyzed {len(results)} image(s)")
    for i, result in enumerate(results):
        print(f"\nImage {i+1}: {result.get('filename')}")
        print(f"  Room Type: {result.get('room_type')}")
        print(f"  Attributes: {[attr['attribute'] for attr in result.get('attributes', [])]}")
else:
    print(f"ERROR: {response.text}")
