# BetaV4 - October 14, 2025

## Version Overview
BetaV4 represents a fully functional multi-tenant property listing generator with integrated photographer portal and agent dashboard.

## Key Features Implemented

### 1. Multi-Tenant Authentication System
- Organization → Office → User hierarchy
- Savills London demo setup with multiple agents
- Role-based access (agent, photographer)
- Email-based login with PIN verification
- localStorage session management

### 2. Agent Portal (James Smith - Savills London)
- **Pre-populated Agent Details:**
  - Agent Name: James Smith
  - Agent Phone: +44 7700 900123
  - Agent Email: james.smith@savills.com
  - Office Phone: +44 20 7499 8644
  - Office Email: london@savills.com
  - Pre-loaded agent headshot (5MB limit, up from 2MB)

### 3. Photographer Portal (Anya Rowlings)
- Multi-photographer support with photographer name tracking
- Photo upload interface with drag-and-drop
- Agent assignment system
- Upload history tracking
- Property folder organization

### 4. Photographer Uploads Display
- **Side-by-side layout:**
  - Left box: Photographer selector dropdown (250px fixed width)
  - Right box: Folder grid (4 columns, responsive)
- Compact folder cards with hover effects
- Empty state when no photographer selected
- Load photos directly into main gallery

### 5. Photo Requirements
- Minimum 8 photos (down from 15)
- Cover photo: 1+ required
- Exterior photos: 3+ required
- Interior photos: 3+ required
- Progress tracker with visual indicators

### 6. Brand Profiles
- Savills branding integration
- Generic/independent agency support
- Logo upload and management
- Brand-specific color schemes

### 7. AI-Powered Generation
- Claude-powered listing descriptions
- Image analysis with fallback system
- Multiple tone and audience options
- Channel-specific optimization (Rightmove, Brochure, Social, Email)

## Technical Stack
- **Backend:** FastAPI (Python)
- **Frontend:** Vanilla JavaScript, HTML5, CSS3
- **AI:** Anthropic Claude API
- **Storage:** File system + JSON data stores
- **Authentication:** Custom auth system with auth_data.json

## File Structure
```
property-listing-generator/
├── backend/
│   └── main.py (FastAPI server with auth endpoints)
├── frontend/
│   ├── index.html (Main agent portal)
│   ├── login.html (Authentication page)
│   ├── photographer_portal.html (Photographer upload interface)
│   ├── app_v2.js (Main application logic)
│   ├── auth.js (Authentication client)
│   ├── theme.js (Brand theming)
│   └── [other support files]
├── services/
│   ├── auth_system.py (Multi-tenant auth)
│   ├── brand_profiles.py (Brand management)
│   ├── generator.py (AI generation)
│   └── [other services]
├── uploads/
│   ├── agent_assets/ (Agent headshots)
│   └── savills_london/ (Photo uploads by office)
├── auth_data.json (User and upload data)
└── brand_profiles.json (Brand configurations)
```

## Recent Changes in BetaV4

### Agent Details Pre-population
- Automatic form filling for James Smith
- Office contact fields added
- Agent headshot pre-loading from server
- 5MB photo size limit

### Photographer Multi-tenancy
- Photographer name field added to uploads
- Dropdown filtering by photographer
- Upload history per photographer
- Clean data management

### UI/UX Improvements
- Photographer selector in separate box (left side)
- Folder grid in separate box (right side, 4 columns)
- Compact folder cards
- No overlap between dropdown and folders
- Empty state messaging
- Deferred folder loading (only after selection)

### Photo Requirements
- Reduced minimum from 15 to 8 photos
- Updated progress indicators
- Validation logic adjusted

## Demo Credentials

### Agent Login
- Email: james.smith@savills.com
- Organization: Savills
- Office: London
- PIN: 2025

### Photographer Login
- Email: photographer@savills.com
- Name: Anya Rowlings
- Organization: Savills
- Office: London
- PIN: 2025

## How to Start
```bash
cd "C:\Users\billm\Desktop\Listing agent\property-listing-generator"
python -m uvicorn backend.main:app --reload
```

Then navigate to: http://localhost:8000/static/login.html

## API Endpoints
- `POST /auth/login` - User authentication
- `POST /photographer/upload` - Photo upload
- `GET /photographer/uploads` - Upload history
- `GET /office/photographer-uploads/{office_id}` - Office uploads
- `POST /generate` - AI listing generation
- `POST /export/pdf` - PDF brochure export
- `POST /export/pack` - Marketing pack ZIP

## Data Stores
- `auth_data.json` - Users, organizations, offices, uploads
- `brand_profiles.json` - Brand configurations
- `user_usage_data.json` - Usage tracking

## Next Development Priorities
1. Multiple photographer support scaling
2. Photo approval workflow
3. Agent-photographer messaging
4. Bulk operations
5. Advanced filtering and search
6. Analytics dashboard
7. Export templates customization

## Notes
- All changes auto-reload with --reload flag
- Photographer uploads stored per office in `/uploads/{office_id}/`
- Session data in localStorage (userEmail, userName, officeId, orgId)
- Mock vision analysis in use (can enable Google Vision)

---
**Version:** BetaV4
**Date:** October 14, 2025
**Status:** Stable
**Compatibility:** Windows 10+, Python 3.8+, Modern browsers
