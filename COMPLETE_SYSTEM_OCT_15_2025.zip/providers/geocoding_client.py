"""
Geocoding client for UK postcodes using postcodes.io API.
Free, no API key required, UK-specific.
"""
import httpx
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class GeocodingClient:
    """
    Client for postcodes.io API to geocode UK postcodes.
    
    API: https://postcodes.io/
    Free, no authentication required.
    """
    
    BASE_URL = "https://api.postcodes.io"
    
    def __init__(self, timeout_seconds: int = 10):
        """
        Initialize the geocoding client.
        
        Args:
            timeout_seconds: HTTP request timeout
        """
        self.timeout = timeout_seconds
        self.client = httpx.AsyncClient(timeout=self.timeout)
    
    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()
    
    async def lookup_postcode(self, postcode: str) -> Optional[dict]:
        """
        Look up a UK postcode and return coordinates and location data.
        
        Args:
            postcode: UK postcode (e.g., "M1 4BT", "SW1A 1AA")
            
        Returns:
            Dictionary with:
            - latitude: float
            - longitude: float
            - postcode: str (normalized)
            - district: str
            - county: str
            - country: str
            Returns None if postcode not found or API error.
        """
        # Normalize postcode (remove spaces, uppercase)
        normalized = postcode.replace(" ", "").upper()
        
        try:
            url = f"{self.BASE_URL}/postcodes/{normalized}"
            logger.info(f"Geocoding postcode: {postcode}")
            
            response = await self.client.get(url)
            
            if response.status_code == 404:
                logger.warning(f"Postcode not found: {postcode}")
                return None
            
            if response.status_code != 200:
                logger.error(f"Geocoding API error: {response.status_code}")
                return None
            
            data = response.json()
            
            if data.get("status") != 200:
                logger.error(f"Geocoding API returned non-200 status: {data}")
                return None
            
            result = data.get("result", {})
            
            return {
                "latitude": result.get("latitude"),
                "longitude": result.get("longitude"),
                "postcode": result.get("postcode"),
                "district": result.get("admin_district"),
                "county": result.get("admin_county"),
                "country": result.get("country"),
            }
            
        except httpx.TimeoutException:
            logger.error(f"Geocoding timeout for postcode: {postcode}")
            return None
        except httpx.RequestError as e:
            logger.error(f"Geocoding request error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected geocoding error: {e}")
            return None
