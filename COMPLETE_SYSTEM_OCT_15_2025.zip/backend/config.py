"""
Configuration module for the Property Listing Generator backend.
Loads settings from environment variables.
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    backend_host: str = "0.0.0.0"
    backend_port: int = 8000
    api_key_placeholder: str = "your-api-key-here"
    log_level: str = "INFO"
    anthropic_api_key: Optional[str] = None
    
    # Vision provider settings
    vision_provider: str = "claude"  # mock | google | claude
    vision_max_image_mb: int = 8
    vision_allowed_types: str = "jpg,jpeg,png,webp"
    google_application_credentials: Optional[str] = None
    
    # Enrichment settings
    enrichment_enabled: bool = True
    enrichment_cache_ttl_seconds: int = 3600  # 1 hour
    enrichment_cache_max_size: int = 1000
    enrichment_timeout_seconds: int = 10
    
    # Compliance settings
    compliance_required_keywords: str = "garden,parking,schools,epc,transport,bathroom,bedroom,kitchen"
    compliance_strict_mode: bool = False
    
    # UI/Editor settings
    editor_max_variants: int = 5
    shrink_enabled: bool = True
    editor_show_hygiene: bool = True
    
    # Export settings
    pdf_max_size_mb: float = 10.0
    pdf_template: str = "simple"  # simple | classic | premium
    pdf_enable_qr: bool = True
    pdf_qr_target_url: Optional[str] = None
    
    # Branding defaults
    export_agency_name: str = "Your Agency"
    export_agency_phone: str = "+44 0000 000000"
    export_agency_email: str = "info@example.com"
    export_brand_primary: str = "#0A5FFF"
    export_brand_secondary: str = "#0B1B2B"
    export_logo_path: Optional[str] = "./branding/logo.png"
    
    # Portal & Social settings
    portal_format: str = "rightmove"
    social_hashtags_default: str = "#NewListing #Property #ForSale"
    
    # Export storage
    export_tmp_dir: str = "./exports_tmp"
    export_retention_hours: int = 24
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
