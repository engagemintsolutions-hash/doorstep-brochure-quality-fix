"""
FastAPI application for Property Listing Generator.
"""
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from typing import List, Optional, Dict
import logging
import asyncio
import os
import time
import uuid
from pathlib import Path

from backend.config import settings
from backend.schemas import (
    HealthResponse,
    GenerateRequest,
    GenerateResponse,
    ShrinkRequest,
    ShrinkResponse,
    ImageAnalysisResponse,
    EnrichmentRequest,
    EnrichmentResponse,
    POIResult,
    ComplianceCheckRequest,
    ComplianceCheckResponse,
    ComplianceWarning,
    KeywordCoverageResult,
    # Collaboration schemas
    UserSession,
    BrochureState,
    ShareBrochureRequest,
    HandoffNotification,
    PendingHandoffsResponse,
    AcceptHandoffResponse,
    HeartbeatRequest,
    ActiveUsersResponse,
)
from backend.schemas_export import (
    PDFExportRequest,
    PackExportRequest,
    ExportResponse,
    PackExportResponse,
)
from services.generator import Generator
from services.rewrite_compressor import RewriteCompressor
from services.shrink_service import ShrinkService
from services.vision_adapter import VisionAdapter, ValidationError
from services.claude_client import ClaudeClient
from services.enrichment_service import EnrichmentService
from services.cache_manager import CacheManager
from services.compliance_checker import ComplianceChecker
from services.keyword_coverage import KeywordCoverage
from services.length_policy import LengthPolicy
from services.export_service import ExportService
from services.rate_limiter import GlobalRateLimiter
from services.agency_templates import (
    get_template_service,
    AgencyBranding,
    PropertyCharacter,
    TemplateType
)
from providers import VisionProvider, make_vision_client
from providers.geocoding_client import GeocodingClient
from providers.places_client import PlacesClient

# Configure logging
logging.basicConfig(level=settings.log_level)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Property Listing Generator",
    description="AI-powered property listing copy generation",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Disable caching for development
@app.middleware("http")
async def disable_cache(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

# Mount static files (frontend)
app.mount("/static", StaticFiles(directory="frontend"), name="static")

# Mount branding files
app.mount("/branding", StaticFiles(directory="branding"), name="branding")

# Mount uploads directory (photographer photos)
if not os.path.exists("uploads"):
    os.makedirs("uploads")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Initialize global rate limiter for API calls
# This prevents acceleration limit errors when multiple photos are analyzed
global_rate_limiter = GlobalRateLimiter(min_delay_seconds=1.2)
logger.info("Global rate limiter initialized (1.2s minimum delay)")

# ============================================================================
# COLLABORATION IN-MEMORY STORAGE
# ============================================================================
# Active user sessions: {user_email: UserSession}
active_sessions: Dict[str, UserSession] = {}
# Pending handoffs: {recipient_email: [list of handoff dicts]}
pending_handoffs: Dict[str, List[Dict]] = {}
# Session expiry: 5 minutes
SESSION_EXPIRY_SECONDS = 300

def _cleanup_expired_sessions():
    """Remove sessions older than SESSION_EXPIRY_SECONDS."""
    current_time = time.time()
    expired = [email for email, session in active_sessions.items()
               if current_time - session.last_seen > SESSION_EXPIRY_SECONDS]
    for email in expired:
        del active_sessions[email]
        logger.debug(f"Expired session for {email}")

# Initialize Claude client
try:
    claude_client = ClaudeClient()
    if claude_client.is_available():
        logger.info("Claude API client initialized successfully")
    else:
        logger.warning("Claude API client not available - using mock generation")
except Exception as e:
    logger.warning(f"Failed to initialize Claude client: {e}")
    claude_client = None

# Initialize vision client with rate limiter
try:
    provider = VisionProvider(settings.vision_provider.lower())
    vision_client = make_vision_client(
        provider=provider,
        config={
            "google_credentials_path": settings.google_application_credentials,
            "anthropic_api_key": settings.anthropic_api_key,
            "rate_limiter": global_rate_limiter  # Pass rate limiter to vision client
        }
    )
    logger.info(f"Vision client initialized: {settings.vision_provider}")
except Exception as e:
    logger.warning(f"Failed to initialize vision client, using mock: {e}")
    vision_client = make_vision_client(VisionProvider.MOCK, {})

# Initialize services
generator = Generator(claude_client=claude_client)
compressor = RewriteCompressor()
vision_adapter = VisionAdapter(
    vision_client=vision_client,
    max_size_mb=settings.vision_max_image_mb,
    allowed_types=settings.vision_allowed_types.split(",")
)
length_policy = LengthPolicy()

# Initialize shrink service (uses Claude if available)
shrink_service = ShrinkService(
    claude_client=claude_client,
    required_keywords=[kw.strip() for kw in settings.compliance_required_keywords.split(",") if kw.strip()]
)

# Initialize enrichment service
enrichment_service = None
if settings.enrichment_enabled:
    try:
        geocoding_client = GeocodingClient(timeout_seconds=settings.enrichment_timeout_seconds)
        places_client = PlacesClient(timeout_seconds=settings.enrichment_timeout_seconds)
        cache_manager = CacheManager(max_size=settings.enrichment_cache_max_size)
        enrichment_service = EnrichmentService(
            geocoding_client=geocoding_client,
            places_client=places_client,
            cache_manager=cache_manager,
        )
        logger.info("Enrichment service initialized")
    except Exception as e:
        logger.warning(f"Failed to initialize enrichment service: {e}")
        enrichment_service = None

# Initialize compliance and keyword coverage services
try:
    required_keywords = settings.compliance_required_keywords.split(",")
    required_keywords = [kw.strip() for kw in required_keywords if kw.strip()]
    compliance_checker = ComplianceChecker(required_keywords=required_keywords)
    keyword_coverage = KeywordCoverage(required_keywords=required_keywords)
    logger.info(f"Compliance services initialized with keywords: {required_keywords}")
except Exception as e:
    logger.warning(f"Failed to initialize compliance services: {e}")
    compliance_checker = ComplianceChecker()
    keyword_coverage = KeywordCoverage()

# Initialize export service
try:
    export_service = ExportService(
        export_dir=settings.export_tmp_dir,
        pdf_max_size_mb=settings.pdf_max_size_mb,
        portal_format=settings.portal_format,
        social_hashtags=settings.social_hashtags_default,
        retention_hours=settings.export_retention_hours
    )
    logger.info("Export service initialized")
except Exception as e:
    logger.warning(f"Failed to initialize export service: {e}")
    export_service = None

# Initialize agency template service
try:
    template_service = get_template_service()
    logger.info(f"Agency template service initialized with {len(template_service.list_agencies())} agencies")
except Exception as e:
    logger.warning(f"Failed to initialize agency template service: {e}")
    template_service = None


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Health check endpoint.
    
    Returns:
        HealthResponse: Service status and version.
    """
    logger.info("Health check requested")
    return HealthResponse(status="ok", version="1.0.0")


@app.post("/generate", response_model=GenerateResponse)
async def generate_listing(request: GenerateRequest):
    """
    Generate property listing variants.
    
    Args:
        request: GenerateRequest with property data, location, audience, tone, channel
        
    Returns:
        GenerateResponse: Generated variants with metadata and optional compliance data
        
    Raises:
        HTTPException: If generation fails
    """
    logger.info(f"Generate request for {request.property_data.property_type} property")
    
    try:
        # Optionally enrich location data
        enrichment_data = None
        if request.include_enrichment and enrichment_service and request.location_data.postcode:
            try:
                logger.info("Enriching location data")
                enrichment_data = await enrichment_service.enrich_location(
                    postcode=request.location_data.postcode
                )
                logger.info(f"Enrichment complete: {len(enrichment_data.get('highlights', []))} highlights")
            except Exception as e:
                logger.warning(f"Enrichment failed, continuing without: {e}")
                enrichment_data = None
        
        # Generate 3 variants (pass enrichment data and photo analysis if available)
        variants = await generator.generate_variants(
            request,
            num_variants=3,
            enrichment_data=enrichment_data,
            photo_analysis=request.photo_analysis
        )
        
        metadata = {
            "channel": request.channel.channel.value,
            "tone": request.tone.tone.value,
            "target_words": request.channel.target_words,
            "hard_cap": request.channel.hard_cap,
            "enrichment_used": enrichment_data is not None,
            "target_ranges": {
                "headline_chars": [50, 90],
                "full_text_words": [
                    request.channel.target_words or 150,
                    request.channel.hard_cap or 300
                ] if request.channel.target_words else [150, 300],
                "features_count": [6, 10]
            }
        }
        
        # Optionally run compliance check on first variant
        compliance_response = None
        if request.include_compliance and variants:
            try:
                logger.info("Running compliance check on generated variant")
                
                # Use the first variant's full text for compliance check
                first_variant_text = variants[0]["full_text"]
                
                # Convert property_data to dict
                property_data_dict = {
                    "property_type": request.property_data.property_type.value,
                    "bedrooms": request.property_data.bedrooms,
                    "bathrooms": request.property_data.bathrooms,
                    "epc_rating": request.property_data.epc_rating,
                    "features": request.property_data.features,
                }
                
                # Run compliance check
                compliance_result = compliance_checker.check_compliance(
                    text=first_variant_text,
                    channel=request.channel.channel,
                    property_data=property_data_dict
                )
                
                # Run keyword coverage analysis
                keyword_result = keyword_coverage.analyze_coverage(
                    text=first_variant_text,
                    channel=request.channel.channel,
                    property_features=request.property_data.features
                )
                
                # Convert warnings to ComplianceWarning objects
                warnings = [
                    ComplianceWarning(
                        severity=w["severity"],
                        message=w["message"],
                        suggestion=w.get("suggestion")
                    )
                    for w in compliance_result["warnings"]
                ]
                
                # Create keyword coverage result
                keyword_coverage_result = KeywordCoverageResult(
                    covered_keywords=keyword_result["covered_keywords"],
                    missing_keywords=keyword_result["missing_keywords"],
                    coverage_score=keyword_result["coverage_score"],
                    suggestions=keyword_result["suggestions"]
                )
                
                # Combine suggestions
                all_suggestions = list(set(
                    compliance_result["suggestions"] + keyword_result["suggestions"]
                ))[:5]
                
                compliance_response = ComplianceCheckResponse(
                    compliant=compliance_result["compliant"],
                    warnings=warnings,
                    compliance_score=compliance_result["score"],
                    keyword_coverage=keyword_coverage_result,
                    suggestions=all_suggestions
                )
                
                logger.info(f"Compliance check complete: score={compliance_result['score']}, compliant={compliance_result['compliant']}")
                
            except Exception as e:
                logger.warning(f"Compliance check failed, continuing without: {e}")
                compliance_response = None
        
        # Convert compliance to dict if present (for Pydantic serialization)
        compliance_dict = compliance_response.model_dump() if compliance_response else None
        
        return GenerateResponse(
            variants=variants,
            metadata=metadata,
            compliance=compliance_dict
        )
        
    except Exception as e:
        logger.error(f"Generation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")


@app.post("/enrich", response_model=EnrichmentResponse)
async def enrich_location(request: EnrichmentRequest):
    """
    Enrich a location with local context data.
    
    Args:
        request: EnrichmentRequest with postcode OR latitude/longitude
        
    Returns:
        EnrichmentResponse: Local amenities, nearest POIs, highlights, descriptors
        
    Raises:
        HTTPException: If enrichment not enabled or request invalid
    """
    logger.info(f"Enrichment request: postcode={request.postcode}, lat={request.latitude}, lon={request.longitude}")
    
    if not settings.enrichment_enabled:
        raise HTTPException(status_code=503, detail="Enrichment service is disabled")
    
    if not enrichment_service:
        raise HTTPException(status_code=503, detail="Enrichment service not available")
    
    # Validate that at least one input is provided
    if not request.postcode and (request.latitude is None or request.longitude is None):
        raise HTTPException(
            status_code=400,
            detail="Must provide either postcode OR both latitude and longitude"
        )
    
    try:
        result = await enrichment_service.enrich_location(
            postcode=request.postcode,
            latitude=request.latitude,
            longitude=request.longitude,
        )
        
        # Convert nearest POIs to POIResult schema
        nearest_converted = {}
        for category, poi in result.get("nearest", {}).items():
            nearest_converted[category] = POIResult(**poi)
        
        return EnrichmentResponse(
            postcode=result["postcode"],
            coordinates=result["coordinates"],
            amenities=result["amenities"],
            nearest=nearest_converted,
            highlights=result["highlights"],
            descriptors=result["descriptors"],
        )
        
    except Exception as e:
        logger.error(f"Enrichment failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Enrichment failed: {str(e)}")


@app.post("/compliance/check", response_model=ComplianceCheckResponse)
async def check_compliance(request: ComplianceCheckRequest):
    """
    Check property listing text for compliance and keyword coverage.
    
    Args:
        request: ComplianceCheckRequest with text, channel, and optional property data
        
    Returns:
        ComplianceCheckResponse: Compliance analysis with warnings and keyword coverage
        
    Raises:
        HTTPException: If compliance check fails
    """
    logger.info(f"Compliance check request for {request.channel} channel")
    
    try:
        # Convert property_data to dict if provided
        property_data_dict = None
        if request.property_data:
            property_data_dict = {
                "property_type": request.property_data.property_type.value,
                "bedrooms": request.property_data.bedrooms,
                "bathrooms": request.property_data.bathrooms,
                "epc_rating": request.property_data.epc_rating,
                "features": request.property_data.features,
            }
        
        # Run compliance check
        compliance_result = compliance_checker.check_compliance(
            text=request.text,
            channel=request.channel,
            property_data=property_data_dict
        )
        
        # Run keyword coverage analysis
        property_features = request.property_data.features if request.property_data else None
        keyword_result = keyword_coverage.analyze_coverage(
            text=request.text,
            channel=request.channel,
            property_features=property_features
        )
        
        # Convert warnings to ComplianceWarning objects
        warnings = [
            ComplianceWarning(
                severity=w["severity"],
                message=w["message"],
                suggestion=w.get("suggestion")
            )
            for w in compliance_result["warnings"]
        ]
        
        # Create keyword coverage result
        keyword_coverage_result = KeywordCoverageResult(
            covered_keywords=keyword_result["covered_keywords"],
            missing_keywords=keyword_result["missing_keywords"],
            coverage_score=keyword_result["coverage_score"],
            suggestions=keyword_result["suggestions"]
        )
        
        # Combine suggestions
        all_suggestions = list(set(
            compliance_result["suggestions"] + keyword_result["suggestions"]
        ))[:5]  # Limit to 5
        
        return ComplianceCheckResponse(
            compliant=compliance_result["compliant"],
            warnings=warnings,
            compliance_score=compliance_result["score"],
            keyword_coverage=keyword_coverage_result,
            suggestions=all_suggestions
        )
        
    except Exception as e:
        logger.error(f"Compliance check failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Compliance check failed: {str(e)}")


@app.post("/shrink", response_model=ShrinkResponse)
async def shrink_text(request: ShrinkRequest):
    """
    Compress text to target word count while preserving tone and keywords.
    
    Args:
        request: ShrinkRequest with text, target word count, optional tone/channel, and keywords
        
    Returns:
        ShrinkResponse: Compressed text with metrics
        
    Raises:
        HTTPException: If compression fails
    """
    logger.info(f"Shrink request: target {request.target_words} words, tone={request.tone}, channel={request.channel}")
    
    if not settings.shrink_enabled:
        raise HTTPException(status_code=503, detail="Shrink feature is disabled")
    
    try:
        result = await shrink_service.compress(
            text=request.text,
            target_words=request.target_words,
            tone=request.tone,
            channel=request.channel,
            preserve_keywords=request.preserve_keywords
        )
        return result
        
    except Exception as e:
        logger.error(f"Compression failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Compression failed: {str(e)}")


@app.post("/analyze-images")
async def analyze_images(files: List[UploadFile] = File(...)):
    """
    Analyze uploaded property images.

    Args:
        files: List of image files to analyze

    Returns:
        List[ImageAnalysisResponse]: Analysis results for each image

    Raises:
        HTTPException: If analysis fails
    """
    logger.info(f"Image analysis request received: {len(files) if files else 0} files")

    if not files:
        raise HTTPException(status_code=422, detail="No files provided")
    
    try:
        results = []
        for file in files:
            # Read file content
            content = await file.read()

            try:
                # Analyze image (rate limiting handled by GlobalRateLimiter in vision client)
                analysis = await vision_adapter.analyze_image(
                    image_data=content,
                    filename=file.filename
                )
                results.append(analysis)
            except ValidationError as e:
                # Return validation error for specific file
                logger.warning(f"Validation failed for {file.filename}: {str(e)}")
                raise HTTPException(status_code=400, detail=f"{file.filename}: {str(e)}")

        return results
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Image analysis failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Image analysis failed: {str(e)}")


@app.post("/export/pdf", response_model=ExportResponse)
async def export_pdf(request: PDFExportRequest):
    """
    Generate a branded PDF brochure.
    
    Args:
        request: PDF export request with listing data, images, and branding
        
    Returns:
        ExportResponse: Export metadata with download URL
        
    Raises:
        HTTPException: If export service unavailable or generation fails
    """
    if not export_service:
        raise HTTPException(status_code=503, detail="Export service not available")
    
    logger.info(f"PDF export requested for {request.listing_data.address}")
    
    try:
        # Generate PDF
        result = export_service.generate_pdf(
            listing_data=request.listing_data,
            images=request.images,
            branding=request.branding,
            options=request.options
        )
        
        # Build response
        response = ExportResponse(
            export_id=result["export_id"],
            download_url=f"/export/{result['export_id']}",
            size_bytes=result["size_bytes"],
            size_mb=result["size_mb"],
            size_warning_exceeded=result["size_warning_exceeded"],
            meta=result["meta"]
        )
        
        logger.info(f"PDF generated: {result['export_id']} ({result['size_mb']} MB)")
        
        return response
        
    except Exception as e:
        logger.error(f"PDF export failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"PDF export failed: {str(e)}")


@app.post("/export/pack", response_model=PackExportResponse)
async def export_pack(request: PackExportRequest):
    """
    Generate a complete marketing pack (PDF + portal + social + email).
    
    Args:
        request: Pack export request with listing data, images, and branding
        
    Returns:
        PackExportResponse: Export metadata with download URL and contents manifest
        
    Raises:
        HTTPException: If export service unavailable or generation fails
    """
    if not export_service:
        raise HTTPException(status_code=503, detail="Export service not available")
    
    logger.info(f"Marketing pack export requested for {request.listing_data.address}")
    
    try:
        # Generate marketing pack
        result = export_service.generate_marketing_pack(
            listing_data=request.listing_data,
            images=request.images,
            branding=request.branding,
            options=request.options
        )
        
        # Build response
        response = PackExportResponse(
            export_id=result["export_id"],
            download_url=f"/export/{result['export_id']}",
            size_bytes=result["size_bytes"],
            size_mb=result["size_mb"],
            contents=result["contents"]
        )
        
        logger.info(f"Marketing pack generated: {result['export_id']} ({result['size_mb']} MB)")
        
        return response
        
    except Exception as e:
        logger.error(f"Pack export failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Pack export failed: {str(e)}")


@app.get("/export/{export_id}")
async def get_export(export_id: str):
    """
    Retrieve a previously generated export (PDF or ZIP).
    
    Args:
        export_id: Export identifier returned from /export/pdf or /export/pack
        
    Returns:
        FileResponse: The requested file for download
        
    Raises:
        HTTPException: If export not found or export service unavailable
    """
    if not export_service:
        raise HTTPException(status_code=503, detail="Export service not available")
    
    logger.info(f"Export retrieval requested: {export_id}")
    
    try:
        # Get export metadata
        export_info = export_service.get_export(export_id)
        
        # Determine media type
        media_type = "application/pdf" if export_info["file_type"] == "pdf" else "application/zip"
        
        # Determine filename
        filename = f"{export_id}.{export_info['file_type']}"
        
        # Return file
        return FileResponse(
            path=export_info["file_path"],
            media_type=media_type,
            filename=filename
        )
        
    except FileNotFoundError:
        logger.warning(f"Export not found: {export_id}")
        raise HTTPException(status_code=404, detail=f"Export not found: {export_id}")
    except Exception as e:
        logger.error(f"Export retrieval failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Export retrieval failed: {str(e)}")


@app.post("/refine-text")
async def refine_text(request: dict):
    """
    Refine property text using AI.

    Args:
        request: Dictionary with 'text' and 'instruction' fields

    Returns:
        Dictionary with refined text
    """
    try:
        text = request.get("text", "")
        instruction = request.get("instruction", "")

        if not text or not instruction:
            raise HTTPException(status_code=400, detail="Both 'text' and 'instruction' are required")

        logger.info(f"Refining text with instruction: {instruction[:50]}...")

        # Build refinement prompt
        prompt = f"""You are an expert property copywriter. The user wants to refine this text:

TEXT:
{text}

INSTRUCTION:
{instruction}

Please provide the refined version that follows their instruction while maintaining professional property marketing standards. Return ONLY the refined text, nothing else."""

        # Use Claude to refine
        if claude_client and claude_client.is_available():
            response = await claude_client.generate_completion(
                prompt=prompt,
                max_tokens=1000,
                temperature=0.7
            )
            refined_text = response.strip()
        else:
            # Fallback: return original with note
            refined_text = f"[Mock refinement] {text}"

        return {"refined_text": refined_text}

    except Exception as e:
        logger.error(f"Text refinement failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Text refinement failed: {str(e)}")


@app.post("/export/brochure-pdf")
async def export_brochure_pdf(request: dict):
    """
    Export brochure HTML to PDF.

    Args:
        request: Brochure data from editor

    Returns:
        PDF file
    """
    try:
        logger.info("Generating brochure PDF from HTML")

        # For now, return a simple response
        # TODO: Implement HTML to PDF conversion using weasyprint or similar
        raise HTTPException(
            status_code=501,
            detail="PDF export not yet implemented. Use browser Print to PDF for now."
        )

    except Exception as e:
        logger.error(f"Brochure PDF export failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Brochure PDF export failed: {str(e)}")


# ============================================================================
# NEW ENDPOINTS: Content Generators + Usage Tracking + Brand Profiles
# ============================================================================

from services.usage_tracker import UsageTracker
from services.content_generators import (
    RightmoveGenerator,
    SocialMediaGenerator,
    EmailCampaignGenerator
)
from services.brand_profiles import BrandProfileManager, get_brand_profile

# Initialize new services
usage_tracker = UsageTracker()
rightmove_gen = RightmoveGenerator(claude_client)
social_gen = SocialMediaGenerator(claude_client)
email_gen = EmailCampaignGenerator(claude_client)
brand_manager = BrandProfileManager()

logger.info("Initialized content generators and usage tracking")


@app.get("/usage/check")
async def check_usage(user_email: str):
    """
    Check user's free trial / subscription status.

    Args:
        user_email: User email address

    Returns:
        Usage data and trial status
    """
    try:
        usage_data = usage_tracker.get_user_usage(user_email)
        can_create, message = usage_tracker.can_create_brochure(user_email)

        return {
            "user_email": user_email,
            "can_create_brochure": can_create,
            "message": message,
            "usage": usage_data
        }

    except Exception as e:
        logger.error(f"Usage check failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/usage/stats")
async def get_usage_stats():
    """
    Get overall usage statistics (admin endpoint).

    Returns:
        Total users, brochures, etc.
    """
    try:
        stats = usage_tracker.get_stats()
        return stats

    except Exception as e:
        logger.error(f"Stats retrieval failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/content/rightmove")
async def generate_rightmove_description(request: dict):
    """
    Generate Rightmove-optimized description (80 words max).

    Args:
        request: {
            "property_data": {...},
            "location_data": {...},
            "main_description": "...",  # optional
            "brand_profile_id": "savills"  # optional
        }

    Returns:
        {"description": "80-word Rightmove description"}
    """
    try:
        property_data = request.get("property_data", {})
        location_data = request.get("location_data", {})
        main_description = request.get("main_description")
        brand_profile_id = request.get("brand_profile_id", "generic")

        brand_profile = get_brand_profile(brand_profile_id)

        description = await rightmove_gen.generate(
            property_data=property_data,
            location_data=location_data,
            main_description=main_description,
            brand_profile=brand_profile
        )

        return {
            "description": description,
            "word_count": len(description.split()),
            "character_count": len(description)
        }

    except Exception as e:
        logger.error(f"Rightmove generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/content/social-media")
async def generate_social_media_content(request: dict):
    """
    Generate social media posts (Instagram + Facebook).

    Args:
        request: {
            "property_data": {...},
            "location_data": {...},
            "platforms": ["instagram", "facebook"]  # optional
        }

    Returns:
        {
            "instagram": [{caption, hashtags, cta}, ...],
            "facebook": [{post_text, cta}, ...]
        }
    """
    try:
        property_data = request.get("property_data", {})
        location_data = request.get("location_data", {})
        platforms = request.get("platforms", ["instagram", "facebook"])

        result = {}

        if "instagram" in platforms:
            instagram_posts = await social_gen.generate_instagram_posts(
                property_data=property_data,
                location_data=location_data,
                num_variants=3
            )
            result["instagram"] = instagram_posts

        if "facebook" in platforms:
            facebook_posts = await social_gen.generate_facebook_posts(
                property_data=property_data,
                location_data=location_data,
                num_variants=3
            )
            result["facebook"] = facebook_posts

        return result

    except Exception as e:
        logger.error(f"Social media generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/content/email-campaign")
async def generate_email_campaign(request: dict):
    """
    Generate "Just Listed" email campaign.

    Args:
        request: {
            "property_data": {...},
            "location_data": {...},
            "agent_details": {...}  # optional
        }

    Returns:
        {
            "subject": "...",
            "preview_text": "...",
            "body_html": "...",
            "body_text": "...",
            "cta": "..."
        }
    """
    try:
        property_data = request.get("property_data", {})
        location_data = request.get("location_data", {})
        agent_details = request.get("agent_details")

        email = await email_gen.generate_just_listed_email(
            property_data=property_data,
            location_data=location_data,
            agent_details=agent_details
        )

        return email

    except Exception as e:
        logger.error(f"Email generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/brand-profiles")
async def list_brand_profiles():
    """
    List all available brand profiles (Savills, generic, etc.).

    Returns:
        List of brand profiles
    """
    try:
        profiles = brand_manager.list_profiles()
        return {"profiles": profiles}

    except Exception as e:
        logger.error(f"Profile listing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/brand-profiles/{profile_id}")
async def get_brand_profile_details(profile_id: str):
    """
    Get details of a specific brand profile.

    Args:
        profile_id: e.g., "savills", "generic"

    Returns:
        Complete brand profile configuration
    """
    try:
        profile = get_brand_profile(profile_id)

        if not profile:
            raise HTTPException(status_code=404, detail=f"Profile not found: {profile_id}")

        return {
            "profile_id": profile.profile_id,
            "name": profile.name,
            "colors": profile.get_colors(),
            "fonts": profile.get_fonts(),
            "layout": profile.get_layout_preferences(),
            "tone": profile.get_tone_preferences(),
            "logo_url": profile.get_logo_url()
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Profile retrieval failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# AUTH SYSTEM: Multi-Tenant Portal for Savills Demo
# ============================================================================

from services.auth_system import AuthSystem, get_auth_system

# Initialize auth system
auth_system_instance = get_auth_system()

logger.info("Initialized auth system with Savills demo data")


@app.get("/auth/organizations")
async def list_organizations():
    """
    List all organizations (e.g., Savills, Independent Agency).

    Returns:
        List of organizations with office counts
    """
    try:
        orgs = auth_system_instance.get_organizations()
        return {"organizations": orgs}

    except Exception as e:
        logger.error(f"Failed to list organizations: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/auth/offices/{org_id}")
async def list_offices(org_id: str):
    """
    List offices for an organization.

    Args:
        org_id: Organization ID (e.g., "savills")

    Returns:
        List of offices for the organization
    """
    try:
        offices = auth_system_instance.get_offices(org_id)
        return {"org_id": org_id, "offices": offices}

    except Exception as e:
        logger.error(f"Failed to list offices: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/auth/login")
async def authenticate_office(request: dict):
    """
    Authenticate access to an office using PIN.

    Args:
        request: {
            "org_id": "savills",
            "office_id": "savills_london",
            "pin": "2025",
            "user_email": "james.smith@savills.com"
        }

    Returns:
        Authentication result with office data
    """
    try:
        org_id = request.get("org_id")
        office_id = request.get("office_id")
        pin = request.get("pin")
        user_email = request.get("user_email")

        if not all([org_id, office_id, pin, user_email]):
            raise HTTPException(status_code=400, detail="Missing required fields")

        # Authenticate office PIN
        success, message = auth_system_instance.authenticate_office(org_id, office_id, pin)

        if not success:
            raise HTTPException(status_code=401, detail=message)

        # Get user data
        user = auth_system_instance.get_user(user_email)

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if user["office_id"] != office_id:
            raise HTTPException(status_code=403, detail="User not authorized for this office")

        # Get office stats
        stats = auth_system_instance.get_office_stats(office_id)

        return {
            "success": True,
            "message": "Authentication successful",
            "user": user,
            "office": {
                "office_id": office_id,
                "org_id": org_id
            },
            "stats": stats
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Authentication failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/office/brochures/{office_id}")
async def get_office_brochures(office_id: str):
    """
    Get all brochures for an office (shared library).

    All team members can see these.

    Args:
        office_id: Office ID (e.g., "savills_london")

    Returns:
        List of brochures
    """
    try:
        brochures = auth_system_instance.get_office_brochures(office_id)

        return {
            "office_id": office_id,
            "brochures": brochures,
            "count": len(brochures)
        }

    except Exception as e:
        logger.error(f"Failed to retrieve brochures: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/office/brochures/{office_id}")
async def add_office_brochure(office_id: str, request: dict):
    """
    Add a brochure to the office's shared library.

    Args:
        office_id: Office ID
        request: Brochure metadata

    Returns:
        Success confirmation
    """
    try:
        auth_system_instance.add_brochure_to_office(office_id, request)

        return {
            "success": True,
            "message": "Brochure added to office library",
            "office_id": office_id
        }

    except Exception as e:
        logger.error(f"Failed to add brochure: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/office/photographer-uploads/{office_id}")
async def get_photographer_uploads(office_id: str):
    """
    Get pending photographer uploads for an office.

    Photographers upload photos, agents assign properties and create brochures.

    Args:
        office_id: Office ID

    Returns:
        List of pending photo uploads
    """
    try:
        uploads = auth_system_instance.get_photographer_uploads(office_id)

        return {
            "office_id": office_id,
            "uploads": uploads,
            "count": len(uploads)
        }

    except Exception as e:
        logger.error(f"Failed to retrieve uploads: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/office/photographer-uploads/{office_id}")
async def add_photographer_upload(office_id: str, request: dict):
    """
    Add photographer upload batch.

    Args:
        office_id: Office ID
        request: Upload metadata with photos

    Returns:
        Success confirmation
    """
    try:
        auth_system_instance.add_photographer_upload(office_id, request)

        return {
            "success": True,
            "message": "Photos uploaded successfully",
            "office_id": office_id
        }

    except Exception as e:
        logger.error(f"Failed to upload photos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/office/stats/{office_id}")
async def get_office_statistics(office_id: str):
    """
    Get statistics for an office.

    Args:
        office_id: Office ID

    Returns:
        Office statistics
    """
    try:
        stats = auth_system_instance.get_office_stats(office_id)

        return {
            "office_id": office_id,
            "stats": stats
        }

    except Exception as e:
        logger.error(f"Failed to retrieve stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# PHOTOGRAPHER PORTAL: Photo Upload and Assignment
# ============================================================================

from fastapi import Form
import os
from datetime import datetime

@app.post("/photographer/upload")
async def upload_photographer_photos(
    property_name: str = Form(...),
    agent_email: str = Form(...),
    photographer_email: str = Form(...),
    photographer_name: str = Form(...),
    office_id: str = Form(...),
    photos: List[UploadFile] = File(...)
):
    """
    Handle photographer photo uploads.

    Photographer uploads photos for a property and assigns to an agent.
    Photos are saved to /uploads/{office_id}/{property_name}/

    Args:
        property_name: Property name (e.g., "Avenue Road")
        agent_email: Agent to assign photos to
        photographer_email: Email of photographer
        office_id: Office ID (e.g., "savills_london")
        photos: List of image files

    Returns:
        Success confirmation with upload_id
    """
    try:
        # Sanitize property name for filesystem
        # Remove invalid characters and strip whitespace
        safe_property_name = property_name.strip()
        # Remove/replace invalid Windows path characters: \ / : * ? " < > |
        invalid_chars = ['\\', '/', ':', '*', '?', '"', '<', '>', '|']
        for char in invalid_chars:
            safe_property_name = safe_property_name.replace(char, '-')
        # Remove any trailing/leading dots or spaces (Windows doesn't like these)
        safe_property_name = safe_property_name.strip('. ')
        # Replace multiple spaces with single space
        import re
        safe_property_name = re.sub(r'\s+', ' ', safe_property_name)

        logger.info(f"📸 Photographer upload: {safe_property_name} ({len(photos)} photos) → {agent_email}")

        # Create upload directory using absolute path construction
        base_dir = os.path.abspath("uploads")
        upload_dir = os.path.join(base_dir, office_id, safe_property_name)

        logger.info(f"Creating directory: {upload_dir}")
        os.makedirs(upload_dir, exist_ok=True)

        # Save photos
        photo_paths = []
        for photo in photos:
            # Generate safe filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_filename = f"{timestamp}_{photo.filename}"
            photo_path = os.path.join(upload_dir, safe_filename)

            logger.info(f"Saving to: {photo_path}")

            # Save file
            with open(photo_path, "wb") as f:
                content = await photo.read()
                f.write(content)

            # Store relative path (use forward slashes for URLs)
            photo_paths.append(f"/uploads/{office_id}/{safe_property_name}/{safe_filename}")
            logger.info(f"  ✓ Saved: {safe_filename}")

        # Create upload record in auth system
        upload_data = {
            "property_name": safe_property_name,
            "agent_email": agent_email,
            "uploaded_by": photographer_email,
            "photographer_name": photographer_name,
            "photo_count": len(photos),
            "photos": photo_paths
        }

        auth_system_instance.add_photographer_upload(office_id, upload_data)

        logger.info(f"✅ Upload complete: {len(photos)} photos saved for {safe_property_name}")

        return {
            "success": True,
            "message": f"Successfully uploaded {len(photos)} photos",
            "property_name": safe_property_name,
            "photo_count": len(photos),
            "agent_email": agent_email
        }

    except Exception as e:
        logger.error(f"❌ Photographer upload failed: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@app.get("/photographer/uploads")
async def get_photographer_upload_history(photographer_email: str):
    """
    Get upload history for a photographer.

    Args:
        photographer_email: Email of photographer

    Returns:
        List of uploads by this photographer
    """
    try:
        logger.info(f"Fetching upload history for {photographer_email}")

        # Get all uploads across all offices (filter by photographer)
        # For now, we'll check savills_london office
        # TODO: Make this work across all offices the photographer has access to

        data = auth_system_instance._load_data()
        all_uploads = []

        for office_id, uploads in data.get("photographer_uploads", {}).items():
            for upload in uploads:
                if upload.get("uploaded_by") == photographer_email:
                    all_uploads.append({
                        "upload_id": upload.get("upload_id"),
                        "property_name": upload.get("property_name"),
                        "agent_email": upload.get("agent_email"),
                        "photo_count": upload.get("photo_count"),
                        "uploaded_at": upload.get("uploaded_at"),
                        "status": upload.get("status"),
                        "office_id": office_id
                    })

        # Sort by upload date (most recent first)
        all_uploads.sort(key=lambda x: x.get("uploaded_at", ""), reverse=True)

        return {
            "photographer_email": photographer_email,
            "uploads": all_uploads,
            "count": len(all_uploads)
        }

    except Exception as e:
        logger.error(f"Failed to fetch upload history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/feedback")
async def submit_feedback(
    experience_rating: Optional[int] = None,
    quality_rating: Optional[int] = None,
    feedback_text: Optional[str] = None,
    time_spent_seconds: int = 0,
    time_saved_seconds: int = 0,
    user_email: str = "anonymous",
    property_address: str = "unknown",
    timestamp: str = None
):
    """
    Submit user feedback and gamification stats after brochure export.

    Args:
        experience_rating: 1-5 rating for overall experience
        quality_rating: 1-5 rating for generated brochure quality
        feedback_text: Optional text feedback
        time_spent_seconds: Time user spent creating brochure
        time_saved_seconds: Estimated time saved vs manual
        user_email: User email (or "anonymous")
        property_address: Property address for context
        timestamp: ISO timestamp

    Returns:
        Confirmation message
    """
    try:
        import json
        from datetime import datetime

        # Prepare feedback data
        feedback_entry = {
            "experience_rating": experience_rating,
            "quality_rating": quality_rating,
            "feedback_text": feedback_text,
            "time_spent_seconds": time_spent_seconds,
            "time_saved_seconds": time_saved_seconds,
            "user_email": user_email,
            "property_address": property_address,
            "timestamp": timestamp or datetime.utcnow().isoformat(),
            "received_at": datetime.utcnow().isoformat()
        }

        logger.info(f"📊 Feedback received from {user_email}")
        logger.info(f"   Experience: {experience_rating}/5, Quality: {quality_rating}/5")
        logger.info(f"   Time spent: {time_spent_seconds}s, Time saved: {time_saved_seconds}s")
        if feedback_text:
            logger.info(f"   Comment: {feedback_text[:100]}...")

        # Store feedback (append to JSON file)
        feedback_file = Path("./feedback_data.json")

        # Load existing feedback
        if feedback_file.exists():
            with open(feedback_file, "r") as f:
                all_feedback = json.load(f)
        else:
            all_feedback = []

        # Append new feedback
        all_feedback.append(feedback_entry)

        # Save back to file
        with open(feedback_file, "w") as f:
            json.dump(all_feedback, f, indent=2)

        logger.info(f"✓ Feedback saved to {feedback_file} (total entries: {len(all_feedback)})")

        return {
            "status": "success",
            "message": "Thank you for your feedback!",
            "feedback_id": len(all_feedback),
            "stored": True
        }

    except Exception as e:
        logger.error(f"Failed to save feedback: {e}")
        # Don't fail the request - feedback is optional
        return {
            "status": "success",
            "message": "Thank you for your feedback!",
            "feedback_id": 0,
            "stored": False
        }


# ===================================================================
# AGENCY BRANDING ENDPOINTS
# ===================================================================

@app.get("/agencies")
async def list_agencies():
    """
    List all available agencies with branding configurations.
    """
    try:
        if not template_service:
            raise HTTPException(status_code=503, detail="Template service not available")

        agencies = template_service.list_agencies()
        return {
            "agencies": agencies,
            "count": len(agencies)
        }
    except Exception as e:
        logger.error(f"Failed to list agencies: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agencies/{agency_id}")
async def get_agency_branding(agency_id: str):
    """
    Get complete branding configuration for an agency.
    """
    try:
        if not template_service:
            raise HTTPException(status_code=503, detail="Template service not available")

        branding = template_service.get_agency_branding(agency_id)
        if not branding:
            raise HTTPException(status_code=404, detail=f"Agency '{agency_id}' not found")

        return branding.dict()
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get agency branding: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agencies/{agency_id}/colors")
async def get_agency_colors(agency_id: str):
    """
    Get color palette for an agency.
    """
    try:
        if not template_service:
            raise HTTPException(status_code=503, detail="Template service not available")

        branding = template_service.get_agency_branding(agency_id)
        if not branding:
            raise HTTPException(status_code=404, detail=f"Agency '{agency_id}' not found")

        return branding.colors.dict()
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get agency colors: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agencies/{agency_id}/logo")
async def get_agency_logo(agency_id: str):
    """
    Get logo file for an agency.
    """
    try:
        if not template_service:
            raise HTTPException(status_code=503, detail="Template service not available")

        logo_path = template_service.get_logo_path(agency_id)
        if not logo_path or not logo_path.exists():
            raise HTTPException(status_code=404, detail=f"Logo not found for agency '{agency_id}'")

        return FileResponse(
            path=str(logo_path),
            media_type="image/png",
            filename=logo_path.name
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get agency logo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/agencies/{agency_id}/select-template")
async def select_template_for_property(
    agency_id: str,
    property_character: PropertyCharacter,
    price: int = None,
    bedrooms: int = None,
    property_type: str = None
):
    """
    Get recommended template for a property based on its characteristics.

    Example request body:
    {
        "property_character": "traditional",
        "price": 750000,
        "bedrooms": 3,
        "property_type": "house"
    }
    """
    try:
        if not template_service:
            raise HTTPException(status_code=503, detail="Template service not available")

        branding = template_service.get_agency_branding(agency_id)
        if not branding:
            raise HTTPException(status_code=404, detail=f"Agency '{agency_id}' not found")

        template = template_service.select_template(
            agency_id=agency_id,
            property_character=property_character,
            price=price,
            bedrooms=bedrooms,
            property_type=property_type
        )

        template_config = branding.templates.get(template)

        return {
            "agency_id": agency_id,
            "selected_template": template.value,
            "template_config": template_config.dict() if template_config else None,
            "property_details": {
                "character": property_character.value,
                "price": price,
                "bedrooms": bedrooms,
                "property_type": property_type
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to select template: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/agencies/{agency_id}/upload-logo")
async def upload_agency_logo(
    agency_id: str,
    file: UploadFile = File(...)
):
    """
    Upload logo for an agency.
    """
    try:
        if not template_service:
            raise HTTPException(status_code=503, detail="Template service not available")

        # Validate file type
        if not file.content_type or not file.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="File must be an image")

        # Read file data
        logo_data = await file.read()

        # Save logo
        logo_path = template_service.save_logo(
            agency_id=agency_id,
            logo_data=logo_data,
            filename=file.filename or "logo.png"
        )

        logger.info(f"Logo uploaded for agency '{agency_id}': {logo_path}")

        return {
            "status": "success",
            "agency_id": agency_id,
            "logo_path": logo_path,
            "filename": file.filename,
            "size": len(logo_data)
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to upload logo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# COLLABORATION ENDPOINTS
# ============================================================================

@app.post("/collaborate/heartbeat")
async def heartbeat(request: HeartbeatRequest):
    """
    Keep user session alive.
    Frontend should call this every 30 seconds.
    """
    try:
        _cleanup_expired_sessions()

        active_sessions[request.user_email] = UserSession(
            user_email=request.user_email,
            user_name=request.user_name,
            last_seen=time.time()
        )

        logger.debug(f"Heartbeat from {request.user_email}")

        return {
            "status": "ok",
            "active_users": len(active_sessions)
        }
    except Exception as e:
        logger.error(f"Heartbeat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/collaborate/active-users", response_model=ActiveUsersResponse)
async def get_active_users(current_user_email: Optional[str] = None):
    """
    Get list of ALL users (excluding current user), with online status.
    Users can send to anyone regardless of online status.
    """
    try:
        _cleanup_expired_sessions()

        # Get current user's office
        current_user = auth_system_instance.get_user(current_user_email) if current_user_email else None
        office_id = current_user.get("office_id") if current_user else "savills_london"  # Default to Savills London

        # Get all users from the same office
        office_users = auth_system_instance.get_office_users(office_id)

        # Build user list with online status
        users = []
        for user_data in office_users:
            email = user_data["email"]

            # Skip current user and photographers
            if email == current_user_email or user_data.get("role") == "photographer":
                continue

            # Check if user has active session
            is_active = email in active_sessions
            last_seen = active_sessions[email].last_seen if is_active else 0

            users.append(UserSession(
                user_email=email,
                user_name=user_data.get("name", email),
                last_seen=last_seen
            ))

        logger.debug(f"All users request: {len(users)} users available from office {office_id}")

        return ActiveUsersResponse(users=users)
    except Exception as e:
        logger.error(f"Get users error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/collaborate/share")
async def share_brochure(request: ShareBrochureRequest):
    """
    Share brochure state with another user.
    """
    try:
        # Generate unique handoff ID
        handoff_id = str(uuid.uuid4())

        # Create handoff notification
        handoff = {
            "handoff_id": handoff_id,
            "sender_email": request.brochure_state.address or "Unknown",  # Temporary sender ID
            "sender_name": request.sender_name,
            "timestamp": time.time(),
            "address": request.brochure_state.address,
            "message": request.message,
            "brochure_state": request.brochure_state.dict()
        }

        # Add to recipient's pending handoffs
        if request.recipient_email not in pending_handoffs:
            pending_handoffs[request.recipient_email] = []

        pending_handoffs[request.recipient_email].append(handoff)

        logger.info(
            f"Brochure shared: {request.sender_name or 'Unknown'} → {request.recipient_email} "
            f"(Address: {request.brochure_state.address})"
        )

        return {
            "status": "success",
            "handoff_id": handoff_id,
            "recipient_email": request.recipient_email
        }
    except Exception as e:
        logger.error(f"Share brochure error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/collaborate/pending", response_model=PendingHandoffsResponse)
async def get_pending_handoffs(user_email: str):
    """
    Get pending brochure handoffs for a user.
    """
    try:
        user_handoffs = pending_handoffs.get(user_email, [])

        notifications = [
            HandoffNotification(
                handoff_id=h["handoff_id"],
                sender_email=h["sender_email"],
                sender_name=h.get("sender_name"),
                timestamp=h["timestamp"],
                address=h.get("address"),
                message=h.get("message")
            )
            for h in user_handoffs
        ]

        logger.debug(f"Pending handoffs for {user_email}: {len(notifications)}")

        return PendingHandoffsResponse(handoffs=notifications)
    except Exception as e:
        logger.error(f"Get pending handoffs error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/collaborate/accept/{handoff_id}", response_model=AcceptHandoffResponse)
async def accept_handoff(handoff_id: str, user_email: str):
    """
    Accept and retrieve a pending handoff.
    This removes the handoff from pending list.
    """
    try:
        user_handoffs = pending_handoffs.get(user_email, [])

        # Find the handoff
        handoff = None
        for i, h in enumerate(user_handoffs):
            if h["handoff_id"] == handoff_id:
                handoff = user_handoffs.pop(i)
                break

        if not handoff:
            raise HTTPException(
                status_code=404,
                detail=f"Handoff {handoff_id} not found for user {user_email}"
            )

        # Convert brochure_state dict back to BrochureState object
        brochure_state = BrochureState(**handoff["brochure_state"])

        logger.info(
            f"Handoff accepted: {handoff_id} by {user_email} "
            f"(from {handoff.get('sender_name', 'Unknown')})"
        )

        return AcceptHandoffResponse(
            brochure_state=brochure_state,
            sender_email=handoff["sender_email"],
            sender_name=handoff.get("sender_name")
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Accept handoff error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=settings.backend_host,
        port=settings.backend_port,
        reload=True
    )
# Trigger reload for auth system
