"""
Comprehensive Implementation Tests
Tests all new features, bug fixes, and integration points
"""

import os
import re
from pathlib import Path
from typing import List, Tuple, Dict

# ANSI color codes
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

class TestResult:
    def __init__(self, name: str, passed: bool, message: str = ""):
        self.name = name
        self.passed = passed
        self.message = message

    def __str__(self):
        status = f"{Colors.GREEN}✓{Colors.RESET}" if self.passed else f"{Colors.RED}✗{Colors.RESET}"
        msg = f" - {self.message}" if self.message else ""
        return f"{status} {self.name}{msg}"

class FeatureTester:
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.results: List[TestResult] = []
        self.total_tests = 0
        self.passed_tests = 0
        self.failed_tests = 0

    def add_result(self, name: str, passed: bool, message: str = ""):
        self.total_tests += 1
        if passed:
            self.passed_tests += 1
        else:
            self.failed_tests += 1
        self.results.append(TestResult(name, passed, message))

    def print_section(self, title: str):
        print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}")
        print(f"  {title}")
        print(f"{'='*60}{Colors.RESET}\n")

    def test_file_exists(self, file_path: str) -> bool:
        full_path = self.base_path / file_path
        exists = full_path.exists()
        self.add_result(
            f"File exists: {file_path}",
            exists,
            f"Size: {full_path.stat().st_size if exists else 0} bytes"
        )
        return exists

    def test_file_content(self, file_path: str, patterns: List[Tuple[str, str]]) -> None:
        """Test if file contains required patterns"""
        full_path = self.base_path / file_path
        if not full_path.exists():
            return

        try:
            content = full_path.read_text(encoding='utf-8')

            for pattern_name, pattern in patterns:
                found = pattern in content or re.search(pattern, content) is not None
                self.add_result(
                    f"  Contains '{pattern_name}'",
                    found
                )
        except Exception as e:
            self.add_result(f"  Error reading {file_path}", False, str(e))

    def test_bulk_operations(self):
        """Test Bulk Photo Operations implementation"""
        self.print_section("1. BULK PHOTO OPERATIONS TESTS")

        js_file = "frontend/bulk_photo_operations.js"
        css_file = "frontend/bulk_photo_operations.css"

        # Test JS file
        if self.test_file_exists(js_file):
            self.test_file_content(js_file, [
                ("bulkPhotoState", r"bulkPhotoState"),
                ("selectedPhotoIds", r"selectedPhotoIds"),
                ("Set data structure", r"new Set\(\)"),
                ("selectAll function", r"(function selectAll|const selectAll)"),
                ("deselectAll function", r"(function deselectAll|const deselectAll)"),
                ("invertSelection", r"invertSelection"),
                ("bulkAddToPage", r"bulkAddToPage"),
                ("bulkDistribute", r"bulkDistribute"),
                ("bulkDelete", r"bulkDelete"),
                ("Shift+Click handler", r"shiftKey"),
                ("Checkbox rendering", r"checkbox"),
                ("Error handling", r"try.*catch"),
                ("Console logging", r"console\.log"),
            ])

        # Test CSS file
        if self.test_file_exists(css_file):
            self.test_file_content(css_file, [
                ("Toolbar styles", r"\.bulk-(toolbar|operations)"),
                ("Checkbox styles", r"\.photo-checkbox"),
                ("Selected state", r"\.selected"),
                ("Badge styles", r"badge"),
                ("Hover effects", r":hover"),
                ("Transition animations", r"transition"),
            ])

    def test_smart_suggestions(self):
        """Test Smart Photo Suggestions implementation"""
        self.print_section("2. SMART PHOTO SUGGESTIONS TESTS")

        js_file = "frontend/smart_photo_suggestions.js"
        css_file = "frontend/smart_photo_suggestions.css"

        if self.test_file_exists(js_file):
            self.test_file_content(js_file, [
                ("analyzePhotoQuality function", r"analyzePhotoQuality"),
                ("Lighting analysis", r"analyzeLighting"),
                ("Composition analysis", r"analyzeComposition"),
                ("Sharpness analysis", r"(analyzeSharpness|estimateSharpness)"),
                ("Color analysis", r"analyzeColor"),
                ("Technical quality", r"analyzeTechnical"),
                ("Grade calculation", r"getQualityGrade"),
                ("Canvas usage", r"canvas|Canvas"),
                ("Image data processing", r"getImageData"),
                ("Quality scoring", r"(overall|score)"),
                ("Recommendation logic", r"recommend"),
                ("Progress tracking", r"progress"),
            ])

        if self.test_file_exists(css_file):
            self.test_file_content(css_file, [
                ("Badge styles", r"\.badge|\.grade"),
                ("Quality grades", r"(grade-a|grade-b|grade-c|grade-d)"),
                ("Recommendation badges", r"\.recommend"),
                ("Color gradients", r"gradient"),
                ("Animation", r"@keyframes|animation"),
            ])

    def test_multi_format_export(self):
        """Test Multi-Format Export implementation"""
        self.print_section("3. MULTI-FORMAT EXPORT TESTS")

        js_file = "frontend/multi_format_export.js"
        css_file = "frontend/multi_format_export.css"

        if self.test_file_exists(js_file):
            self.test_file_content(js_file, [
                ("exportMultipleFormats function", r"exportMultipleFormats"),
                ("JSZip integration", r"JSZip"),
                ("CDN loading", r"loadJSZip"),
                ("PDF generation", r"exportPDF|generatePDF"),
                ("Image generation", r"generatePageImage"),
                ("Canvas rendering", r"canvas\.toBlob|toDataURL"),
                ("JPEG generation", r"image/jpeg"),
                ("PNG generation", r"image/png"),
                ("HTML generation", r"generatePreviewHTML"),
                ("README generation", r"README"),
                ("Progress tracking", r"progress"),
                ("ZIP creation", r"\.folder\(|\.file\("),
                ("Download trigger", r"download"),
                ("Error handling", r"try.*catch"),
            ])

        if self.test_file_exists(css_file):
            self.test_file_content(css_file, [
                ("Progress modal", r"\.progress-modal"),
                ("Format icons", r"\.format-(icon|card)"),
                ("Progress bar", r"\.progress-bar"),
                ("Animation", r"animation"),
            ])

    def test_ux_enhancements(self):
        """Test UX Enhancements implementation"""
        self.print_section("4. UX ENHANCEMENTS TESTS")

        js_file = "frontend/ux_enhancements.js"
        css_file = "frontend/ux_enhancements.css"

        if self.test_file_exists(js_file):
            self.test_file_content(js_file, [
                ("Skeleton screens", r"showSkeletonScreen|hideSkeletonScreen"),
                ("Progressive loading", r"loadImageProgressively"),
                ("Tooltips", r"addTooltip"),
                ("Tooltip data", r"tooltips"),
                ("Optimistic updates", r"optimisticUpdate"),
                ("Optimistic photo upload", r"optimisticPhotoUpload"),
                ("Drag-drop upload", r"enableGlobalDragDrop"),
                ("Drag events", r"dragenter|dragover|drop"),
                ("Preview mode", r"openPreviewMode"),
                ("Device simulation", r"setPreviewDevice"),
                ("Iframe rendering", r"iframe"),
                ("HTML generation", r"generatePreviewHTML"),
            ])

        if self.test_file_exists(css_file):
            self.test_file_content(css_file, [
                ("Skeleton styles", r"\.skeleton"),
                ("Shimmer animation", r"@keyframes shimmer"),
                ("Tooltip styles", r"\.tooltip"),
                ("Drag overlay", r"\.drop-overlay"),
                ("Preview modal", r"\.preview-mode"),
                ("Device frames", r"\.preview-device"),
                ("Responsive design", r"@media"),
                ("Dark mode support", r"prefers-color-scheme"),
                ("Accessibility", r"prefers-reduced-motion"),
            ])

    def test_bug_fixes(self):
        """Test Bug Fixes implementation"""
        self.print_section("5. BUG FIXES TESTS")

        js_file = "frontend/bug_fixes.js"

        if self.test_file_exists(js_file):
            self.test_file_content(js_file, [
                # High priority
                ("Session timer pause", r"pauseSessionTimer"),
                ("Visibility API", r"visibilitychange"),
                ("Global function exports", r"window\.\w+\s*="),
                ("Rate limiter class", r"class.*RateLimiter"),
                ("Rate limiter throttle", r"throttle"),
                ("Global error boundary", r"window\.addEventListener.*error"),
                ("Unhandled rejection", r"unhandledrejection"),

                # Medium priority
                ("localStorage quota", r"checkLocalStorageQuota"),
                ("Template validation", r"validateTemplate"),
                ("Debounce utility", r"function debounce|const debounce"),
                ("Slider validation", r"updatePageCount|updateWordCount"),

                # Low priority
                ("Debug mode", r"window\.DEBUG"),
                ("Conditional logging", r"if.*DEBUG"),
                ("Analytics tracking", r"trackEvent"),
                ("Form validation", r"validateFormInput"),

                # General
                ("Error handling", r"try.*catch"),
                ("Console logging", r"console\.log"),
            ])

    def test_integration(self):
        """Test integration in index.html"""
        self.print_section("6. INTEGRATION TESTS")

        index_file = "frontend/index.html"

        if self.test_file_exists(index_file):
            self.test_file_content(index_file, [
                ("Bulk operations CSS", r"bulk_photo_operations\.css"),
                ("Bulk operations JS", r"bulk_photo_operations\.js"),
                ("Smart suggestions CSS", r"smart_photo_suggestions\.css"),
                ("Smart suggestions JS", r"smart_photo_suggestions\.js"),
                ("Multi-format export CSS", r"multi_format_export\.css"),
                ("Multi-format export JS", r"multi_format_export\.js"),
                ("UX enhancements CSS", r"ux_enhancements\.css"),
                ("UX enhancements JS", r"ux_enhancements\.js"),
                ("Bug fixes JS", r"bug_fixes\.js"),
            ])

    def test_file_sizes(self):
        """Test file sizes are reasonable"""
        self.print_section("7. FILE SIZE TESTS")

        files_to_check = [
            ("frontend/bulk_photo_operations.js", 500, 700),  # Expected ~615 lines
            ("frontend/bulk_photo_operations.css", 300, 400),  # Expected ~357 lines
            ("frontend/smart_photo_suggestions.js", 600, 800),  # Expected ~700+ lines
            ("frontend/smart_photo_suggestions.css", 400, 500),  # Expected ~450+ lines
            ("frontend/multi_format_export.js", 600, 750),  # Expected ~650+ lines
            ("frontend/multi_format_export.css", 350, 450),  # Expected ~380+ lines
            ("frontend/ux_enhancements.js", 500, 650),  # Expected ~550+ lines
            ("frontend/ux_enhancements.css", 450, 550),  # Expected ~500+ lines
            ("frontend/bug_fixes.js", 400, 550),  # Expected ~476 lines
        ]

        for file_path, min_lines, max_lines in files_to_check:
            full_path = self.base_path / file_path
            if full_path.exists():
                try:
                    content = full_path.read_text(encoding='utf-8')
                    lines = len(content.splitlines())
                    in_range = min_lines <= lines <= max_lines
                    self.add_result(
                        f"File size: {file_path}",
                        in_range,
                        f"{lines} lines (expected {min_lines}-{max_lines})"
                    )
                except Exception as e:
                    self.add_result(f"Error checking {file_path}", False, str(e))

    def test_documentation(self):
        """Test documentation exists"""
        self.print_section("8. DOCUMENTATION TESTS")

        doc_files = [
            "BUG_FIXES_IMPLEMENTATION.md",
            "COMPREHENSIVE_TEST_PLAN.md",
        ]

        for doc_file in doc_files:
            if self.test_file_exists(doc_file):
                full_path = self.base_path / doc_file
                content = full_path.read_text(encoding='utf-8')
                lines = len(content.splitlines())
                self.add_result(
                    f"  Documentation complete: {doc_file}",
                    lines > 50,
                    f"{lines} lines"
                )

    def print_summary(self):
        """Print test summary"""
        self.print_section("TEST SUMMARY")

        print(f"Total Tests:  {self.total_tests}")
        print(f"{Colors.GREEN}Passed:       {self.passed_tests}{Colors.RESET}")
        print(f"{Colors.RED}Failed:       {self.failed_tests}{Colors.RESET}")
        success_rate = (self.passed_tests / self.total_tests * 100) if self.total_tests > 0 else 0
        print(f"Success Rate: {success_rate:.1f}%\n")

        # Print failed tests
        failed = [r for r in self.results if not r.passed]
        if failed:
            print(f"{Colors.BOLD}{Colors.RED}Failed Tests:{Colors.RESET}")
            for result in failed:
                print(f"  {result}")
            print()

        # Final verdict
        if self.failed_tests == 0:
            print(f"{Colors.GREEN}{Colors.BOLD}✅ ALL TESTS PASSED{Colors.RESET}\n")
            return 0
        else:
            print(f"{Colors.RED}{Colors.BOLD}❌ SOME TESTS FAILED{Colors.RESET}\n")
            return 1

    def run_all_tests(self):
        """Run all test suites"""
        print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}")
        print("  COMPREHENSIVE IMPLEMENTATION TESTS")
        print(f"  Property Listing Generator v3.0")
        print(f"{'='*60}{Colors.RESET}\n")

        self.test_bulk_operations()
        self.test_smart_suggestions()
        self.test_multi_format_export()
        self.test_ux_enhancements()
        self.test_bug_fixes()
        self.test_integration()
        self.test_file_sizes()
        self.test_documentation()

        return self.print_summary()

def main():
    # Get the base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # Create tester and run all tests
    tester = FeatureTester(base_dir)
    exit_code = tester.run_all_tests()

    exit(exit_code)

if __name__ == "__main__":
    main()
