import anthropic
import base64
import os

# Read API key from .env
with open('.env', 'r') as f:
    for line in f:
        if line.startswith('ANTHROPIC_API_KEY='):
            api_key = line.split('=', 1)[1].strip()
            break

client = anthropic.Anthropic(api_key=api_key)

# Test photos
test_photos = [
    r'C:\Users\billm\Documents\prop test run\front.jpeg',
    r'C:\Users\billm\Documents\prop test run\36239_GUS250140_IMG_01_0000.jpeg',
    r'C:\Users\billm\Documents\prop test run\36239_GUS250140_IMG_05_0000.jpeg',
    r'C:\Users\billm\Documents\prop test run\36239_GUS250140_IMG_10_0000.jpeg',
    r'C:\Users\billm\Documents\prop test run\36239_GUS250140_IMG_15_0000.jpeg',
]

print("Analyzing property photos and generating description...\n")

# Analyze each photo
detected_features = []
room_types = []

for photo_path in test_photos:
    if not os.path.exists(photo_path):
        print(f"Skipping {photo_path} - file not found")
        continue

    with open(photo_path, 'rb') as f:
        image_data = base64.b64encode(f.read()).decode('utf-8')

    print(f"Analyzing: {os.path.basename(photo_path)}")

    message = client.messages.create(
        model="claude-3-haiku-20240307",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": image_data,
                    },
                },
                {
                    "type": "text",
                    "text": """Analyze this property photo. List:
1. Room type
2. Specific features visible (fireplace, garden, driveway, bay windows, french doors, etc.)
3. Materials/finishes (hardwood floors, granite countertops, etc.)

Be specific about what you actually see."""
                }
            ],
        }],
    )

    response = message.content[0].text
    print(f"  {response}\n")
    room_types.append(response.split('\n')[0] if response else "")
    detected_features.append(response)

print("\n" + "="*80)
print("Now generating property description based on all photos...")
print("="*80 + "\n")

# Generate description
all_analysis = "\n\n".join([f"Photo {i+1}:\n{analysis}" for i, analysis in enumerate(detected_features)])

description_message = client.messages.create(
    model="claude-3-5-sonnet-latest",
    max_tokens=2048,
    messages=[{
        "role": "user",
        "content": f"""Based on these property photo analyses, write a compelling 400-500 word property brochure description in a professional, upmarket tone.

Photo Analyses:
{all_analysis}

Write a flowing narrative that highlights the key features, rooms, and selling points. Focus on what makes this property special."""
    }],
)

description = description_message.content[0].text
print(description)
print("\n" + "="*80)
print(f"Word count: {len(description.split())} words")
